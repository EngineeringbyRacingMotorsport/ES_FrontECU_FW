/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define FfINTbuzz_Pin GPIO_PIN_13
#define FfINTbuzz_GPIO_Port GPIOC
#define FfANLRpot_Pin GPIO_PIN_0
#define FfANLRpot_GPIO_Port GPIOA
#define FfANLLpot_Pin GPIO_PIN_1
#define FfANLLpot_GPIO_Port GPIOA
#define FfDIGr2d_Pin GPIO_PIN_4
#define FfDIGr2d_GPIO_Port GPIOA
#define FfANLbrake_Pin GPIO_PIN_0
#define FfANLbrake_GPIO_Port GPIOB
#define FfSUPled_Pin GPIO_PIN_11
#define FfSUPled_GPIO_Port GPIOB
#define FfINTebms_Pin GPIO_PIN_15
#define FfINTebms_GPIO_Port GPIOB
#define FfINTrefrion_Pin GPIO_PIN_15
#define FfINTrefrion_GPIO_Port GPIOA
#define FfINTr2d_Pin GPIO_PIN_9
#define FfINTr2d_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

typedef struct{
	/* ================ MISSATGE 1 ================ */
	uint16_t  FfANLRpot  ;
	uint16_t  FfANLLpot  ;
	uint16_t FfANLRsus  ;
	uint16_t FfANLLsus  ;
	uint8_t  FfDIGRvel  ;
	uint8_t  FfDIGLvel  ;
	uint16_t  FfANLbrake ;

	/* ================ MISSATGE 2 ================ */
	uint8_t  FfINTsbms      ;
	uint8_t  FfINTr2d       ;
	uint8_t  FfINTmenu      ;
	uint8_t  FfDIGmicrosd   ;
	uint8_t  FfSDCinertia   ;
	uint8_t  FfSDCbots      ;
	uint8_t  FfSDCcsdb      ;
	uint8_t  FfERRapps      ;
	uint8_t  FfDIGrefrion   ;
	uint8_t  FfDIGrefriauto ;
	uint8_t  FfDIGr2d       ;
	uint16_t FfSHU          ;
	uint8_t  FfSUPled       ;
	uint8_t  FfINTrefrion   ;
} DICCF_t;

typedef struct {
	/* ================ MISSATGE 1 ================ */
	uint16_t  FpANLRpot  ;
	uint16_t  FpANLLpot  ;
	uint8_t   FpDIGRpot  ;
	uint8_t   FpDIGLpot  ;
	uint8_t   FpDIGRvel  ;
	uint8_t   FpDIGLvel  ;
	uint16_t  FpANLbrake ;

	/* ================ MISSATGE 2 ================ */
	uint8_t  FpDIGvel      ;
	uint8_t  FpANLtaccu    ;
	uint8_t  FpANLvaccu    ;
	uint8_t  FpINTsbms     ;
	uint8_t  FpINTr2d      ;
	uint8_t  FpINTmenu     ;
	uint8_t  FpDIGmicrosd  ;
	uint8_t  FpSDCinertia  ;
	uint8_t  FpSDCbots     ;
	uint8_t  FpSDCcsdb     ;
	uint8_t  FpERRapps     ;
	uint8_t  FpDIGrefri    ;
	uint8_t  FpDIGrefrion  ;
	uint8_t  FpDIGrefriauto;
	uint8_t  FpDIGr2d      ;
	uint8_t  FpINTtsoff	   ;
	uint16_t FpSHU         ;
	uint8_t  FpINTrefrion  ;

	/* ================ HVDB ================ */
	uint8_t  DpSDC		   ;
	uint8_t  SpSDCbms	   ;
	uint8_t  ApTHRhv       ;
} DICCP_t;

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
