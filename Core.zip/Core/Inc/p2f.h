/*
 * p2f.h
 *
 *  Created on: Jun 25, 2026
 *      Author: oriol
 */

#ifndef INC_P2F_H_
#define INC_P2F_H_

#include "main.h"

uint8_t APPS(volatile DICCF_t *DICCF, volatile DICCP_t *DICCP);
void R2D(volatile DICCF_t *DICCF, volatile DICCP_t *DICCP);
void PLC(volatile DICCP_t *DICCP);
void Display(volatile DICCF_t *DICCF, volatile DICCP_t *DICCP);


#endif /* INC_P2F_H_ */
